// import firebase from "firebase/compat/app";
import "firebase/compat/firestore";
import { initializeApp } from 'firebase/app'

const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: "",
};

export default initializeApp(firebaseConfig);
