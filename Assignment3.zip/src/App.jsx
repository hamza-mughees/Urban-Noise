import React, { useEffect, useState } from "react";
import { getData } from "./utils/saveData";

const App = () => {
  const [data, setData] = useState({});
  const [dataLoaded, setDataLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      const currentTime = Math.floor(Date.now() / 1000);
      const oneDayAgo = currentTime - 86400;
      const oneWeekAgo = currentTime - 604800;
      const twoDaysAgo = currentTime - 2 * 86400;

      setData(await getData(twoDaysAgo, currentTime));
      setDataLoaded(true);
    })();
  }, []);

  if (dataLoaded) {
    return <div className="App"></div>;
  }
};

export default App;
