import React, { useState } from "react";
import { motion } from "framer-motion";

const InfoBox = (props) => {
  return <motion.div></motion.div>;
};

export default InfoBox;
