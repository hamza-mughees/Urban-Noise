import React, { useEffect, useState } from "react";

const NoiseChart = (props) => {
  return (
    <div></div>
  );
};

export default NoiseChart;
